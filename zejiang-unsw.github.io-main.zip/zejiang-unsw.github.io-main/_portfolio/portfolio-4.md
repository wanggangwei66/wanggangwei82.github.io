---
title: "ABC Waters: Low impact development (LID) for Singapore environment"
excerpt: "PUB-TMSI-Monash University project <br/><img src='/images/ABC-Waters.jpg'>"
collection: portfolio
---

## Effectiveness of ABC Waters design features in residential developments, PUB-TMSI-Monash University project.

Evaluation of the applications of low impact development (LID) for Singapore environment. Given Singapore is such a small island stat in the tropic, with high rainfall intensity and a rather short time of concentration (of about 30 minutes), we wish to consider its applicability in Singapore. 