---
title: "Future changes in rice yields over the Mekong River Delta due to climate change-Alarming or alerting?"
collection: publications
permalink: /publication/2018-09-07-paper-TAAC
excerpt: 'This paper is about future changes in rice yields over the Mekong River Delta due to climate change.'
date: 2018-09-07
venue: 'Theoretical and Applied Climatology'
paperurl: 'https://doi.org/10.1007/s00704-018-2617-z'
citation: 'Jiang, Z., Raghavan, S. V., Hur, J., Sun, Y., Liong, S.-Y., Nguyen, V. Q., & Van Pham Dang, T. (2019). "Future changes in rice yields over the Mekong River Delta due to climate change-Alarming or alerting?." <i>Theoretical and Applied Climatology</i>. 137(1), 545-555.'
---
This paper is about future changes in rice yields over the Mekong River Delta due to climate change.

[Download paper here](http://zejiang-unsw.github.io/files/Jiang-TAAC-2018.pdf)

