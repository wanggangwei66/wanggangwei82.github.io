---
title: "A wavelet-based method to analyse sustained hydrological anomalies under climate change"
collection: talks
type: "Talk"
permalink: /talks/2019-12-05-talk-MODSIM
venue: "Royal Theatre"
date: 2019-12-05
location: "Canberra, Australia"
---

Recommended citation: Jiang, Z., Sharma, A., and Johnson, F.: A wavelet-based method to analyse sustained hydrological anomalies under climate change, MODSIM 2019, National Convention Centre Canberra, 1-6 December 2019, K22. [Download talk here](http://zejiang-unsw.github.io/files/Jiang-MODSIM-2019.pdf)
