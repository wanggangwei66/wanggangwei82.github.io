---
title: "Drought prediction for improved water resource management: A wavelet-based system prediction approach"
collection: talks
type: "Talk"
permalink: /talks/2019-10-19-talk-STAHY
venue: "Wentian Building, Hohai University"
date: 2019-10-19
location: "Nanjing, China"
---

Recommended citation: Jiang, Z., Sharma, A., and Johnson, F.: Drought prediction for improved water resource management: A wavelet-based system prediction approach, STAHY 2019, Wentian Building, Hohai University, Nanjing, 19-20 October 2019. [Download talk here](http://zejiang-unsw.github.io/files/Jiang-STAHY-2019.pdf)


