---
title: "CVEN3501 Water Resources Engineering"
collection: teaching
type: "Undergraduate course"
permalink: /teaching/2019-T1-WRE_UNSW
venue: "School of Civil and Environmental Engineering, UNSW Sydney"
date: 2019-02-18
location: "Sydney, Australia"
---
* Teaching period: T1, 2019
* Position: Teaching Assistant 
* Role: Demonstrator and Tutor
* Number of students: 610
* Course Profile: [Download](https://vm.civeng.unsw.edu.au/courseprofiles/2019/2019-T1_CVEN3501x7193.pdf)