---
title: "CVEN9625 Fundamentals of Water Engineering"
collection: teaching
type: "Masters course"
permalink: /teaching/2019-T3-WRE_UNSW
venue: "School of Civil and Environmental Engineering, UNSW Sydney"
date: 2019-09-25
location: "Sydney, Australia"
---
* Teaching period: S2, 2018; T1&3, 2019.
* Position: Teaching Assistant 
* Role: Demonstrator and Tutor
* Number of students: ~200
* Course Profile: [Download](https://vm.civeng.unsw.edu.au/courseprofiles/2019/2019-T3_CVEN9625x8224.pdf)